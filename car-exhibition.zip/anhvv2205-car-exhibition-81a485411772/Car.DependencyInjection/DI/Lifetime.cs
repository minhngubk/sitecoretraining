﻿namespace Car.DependencyInjection.DI
{
    public enum Lifetime
    {
        Transient,
        Scoped,
        Singleton
    }
}