﻿namespace Car.DependencyInjection.DI
{
    using Microsoft.Extensions.DependencyInjection;
    using Sitecore.DependencyInjection;

    public class MvcControllerServicesConfigurator : IServicesConfigurator
    {
        private const string ProjectPrefix = "Car";

        public void Configure(IServiceCollection serviceCollection)
        {
            serviceCollection.AddControllers($"{ProjectPrefix}.*");
            serviceCollection.AddClassesWithServiceAttribute($"{ProjectPrefix}.*");
        }
    }
}