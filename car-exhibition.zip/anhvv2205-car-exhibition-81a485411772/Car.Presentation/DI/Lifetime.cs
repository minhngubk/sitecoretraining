﻿namespace VPBank.Presentation.DI
{
    public enum Lifetime
    {
        Transient,
        Singleton
    }
}