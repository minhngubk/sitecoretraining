﻿using Microsoft.Extensions.DependencyInjection;
using Sitecore.DependencyInjection;

namespace VPBank.Presentation.DI
{
    public class ServiceConfigurator : IServicesConfigurator
    {
        public void Configure(IServiceCollection serviceCollection)
        {
            serviceCollection.AddClassesWithServiceAttribute("VPBank.Presentation");
            serviceCollection.AddClassesWithServiceAttribute("VPBank.Service");
        }
    }
}