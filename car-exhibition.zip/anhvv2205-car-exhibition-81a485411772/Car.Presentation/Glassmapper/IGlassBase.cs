﻿using Glass.Mapper.Sc.Configuration;
using Glass.Mapper.Sc.Configuration.Attributes;
using Sitecore.Data;
using Sitecore.Data.Items;
using Sitecore.Globalization;
using System;
using System.Collections.Generic;

namespace Car.Presentation.Glassmapper
{
    public interface IGlassBase
    {
        [SitecoreId]
        Guid Id { get; }

        [SitecoreInfo(SitecoreInfoType.Language)]
        Language Language { get; }

        [SitecoreInfo(SitecoreInfoType.Version)]
        int Version { get; }

        [SitecoreChildren(InferType = true, IsLazy = true)]
        IEnumerable<IGlassBase> Children { get; set; }

        [SitecoreIgnore]
        System.String Content { get; set; }

        [SitecoreField("__Created")]
        DateTime CreatedDate { get; set; }

        [SitecoreField("__Publish")]
        DateTime PublishedDate { get; set; }

        [SitecoreInfo(SitecoreInfoType.DisplayName)]
        System.String DisplayName { get; set; }

        [SitecoreField("__Is Bucket")]
        System.Boolean IsBucket { get; set; }

        [SitecoreIgnore]
        System.Boolean IsLatestVersion { get; set; }

        [SitecoreIgnore]
        Database ItemDatabase { get; }

        [SitecoreItem]
        Item Item { get; }

        [SitecoreIgnore]
        System.Boolean LivesInABucket { get; }

        [SitecoreInfo(SitecoreInfoType.Name)]
        System.String Name { get; set; }

        [SitecoreQuery("./following::*", InferType = true, IsLazy = true, IsRelative = true)]
        IEnumerable<IGlassBase> NextSiblings { get; set; }

        [SitecoreParent(InferType = true, IsLazy = true)]
        IGlassBase Parent { get; set; }

        [SitecoreQuery("./preceding::*", InferType = true, IsLazy = true, IsRelative = true)]
        IEnumerable<IGlassBase> PreviousSiblings { get; set; }

        [SitecoreIgnore]
        System.String ShortIdString { get; }

        [SitecoreIgnore]
        [SitecoreInfo(SitecoreInfoType.TemplateId)]
        Guid TemplateId { get; set; }

        [SitecoreInfo(SitecoreInfoType.TemplateName)]
        System.String TemplateName { get; set; }

        [SitecoreInfo(SitecoreInfoType.BaseTemplateIds)]
        IEnumerable<Guid> BaseTemplateIds { get; set; }

        [SitecoreField("__Updated")]
        DateTime UpdatedDateTime { get; set; }

        [SitecoreInfo(SitecoreInfoType.ItemUri)]
        ItemUri Uri { get; set; }

        [SitecoreInfo(SitecoreInfoType.Url, UrlOptions = SitecoreInfoUrlOptions.EncodeNames | SitecoreInfoUrlOptions.ShortenUrls | SitecoreInfoUrlOptions.SiteResolving | SitecoreInfoUrlOptions.LanguageEmbeddingAlways)]
        string Url { get; set; }

        [SitecoreInfo(SitecoreInfoType.Url, UrlOptions = SitecoreInfoUrlOptions.EncodeNames | SitecoreInfoUrlOptions.AlwaysIncludeServerUrl | SitecoreInfoUrlOptions.SiteResolving | SitecoreInfoUrlOptions.LanguageEmbeddingAlways)]
        string FullUrl { get; set; }
    }
}