﻿using Glass.Mapper.Sc;
using Sitecore.Data;

namespace Car.Service.Interfaces
{
    public interface ISitecoreContextService
    {
        ISitecoreService GetCurrentSitecoreService();

        Database GetContextDatabase();
    }
}
