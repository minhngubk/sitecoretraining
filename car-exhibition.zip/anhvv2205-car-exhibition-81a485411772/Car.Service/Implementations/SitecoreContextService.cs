﻿using Car.DependencyInjection.DI;
using Car.Service.Interfaces;
using Glass.Mapper.Sc;
using Sitecore.Data;

namespace Car.Service.Implementations
{
    [Service(typeof(ISitecoreContextService), Lifetime = Lifetime.Transient)]
    public class SitecoreContextService : ISitecoreContextService
    {
        public ISitecoreService GetCurrentSitecoreService()
        {
            return new SitecoreService(Sitecore.Context.Database);
        }

        public Database GetContextDatabase()
        {
            return Sitecore.Context.Database;
        }
    }
}
