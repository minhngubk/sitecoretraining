﻿using Glass.Mapper.Sc.Configuration;
using Glass.Mapper.Sc.Configuration.Attributes;
using Sitecore.Data;
using Sitecore.Data.Items;
using Sitecore.Globalization;
using System;
using System.Collections.Generic;

namespace Car.Common.Glassmapper
{
    public class GlassBase : IGlassBase
    {
        [SitecoreId]
        public Guid Id { get; }

        [SitecoreInfo(SitecoreInfoType.Language)]
        public Language Language { get; }

        [SitecoreInfo(SitecoreInfoType.Version)]
        public int Version { get; }

        [SitecoreChildren(InferType = true, IsLazy = true)]
        public IEnumerable<IGlassBase> Children { get; set; }

        [SitecoreIgnore]
        public System.String Content { get; set; }

        [SitecoreField("__Created")]
        public DateTime CreatedDate { get; set; }

        [SitecoreField("__Publish")]
        public DateTime PublishedDate { get; set; }

        [SitecoreInfo(SitecoreInfoType.DisplayName)]
        public System.String DisplayName { get; set; }

        [SitecoreField("__Is Bucket")]
        public System.Boolean IsBucket { get; set; }

        [SitecoreIgnore]
        public System.Boolean IsLatestVersion { get; set; }

        [SitecoreIgnore]
        public Database ItemDatabase { get; }

        [SitecoreItem]
        public Item Item { get; }

        [SitecoreIgnore]
        public System.Boolean LivesInABucket { get; }

        [SitecoreInfo(SitecoreInfoType.Name)]
        public System.String Name { get; set; }

        [SitecoreQuery("./following::*", InferType = true, IsLazy = true, IsRelative = true)]
        public IEnumerable<IGlassBase> NextSiblings { get; set; }

        [SitecoreParent(InferType = true, IsLazy = true)]
        public IGlassBase Parent { get; set; }

        [SitecoreQuery("./preceding::*", InferType = true, IsLazy = true, IsRelative = true)]
        public IEnumerable<IGlassBase> PreviousSiblings { get; set; }

        [SitecoreIgnore]
        public System.String ShortIdString { get; }

        [SitecoreIgnore]
        [SitecoreInfo(SitecoreInfoType.TemplateId)]
        public Guid TemplateId { get; set; }

        [SitecoreInfo(SitecoreInfoType.TemplateName)]
        public System.String TemplateName { get; set; }

        [SitecoreInfo(SitecoreInfoType.BaseTemplateIds)]
        public IEnumerable<Guid> BaseTemplateIds { get; set; }

        [SitecoreField("__Updated")]
        public DateTime UpdatedDateTime { get; set; }

        [SitecoreInfo(SitecoreInfoType.ItemUri)]
        public ItemUri Uri { get; set; }

        [SitecoreInfo(SitecoreInfoType.Url, UrlOptions = SitecoreInfoUrlOptions.EncodeNames | SitecoreInfoUrlOptions.ShortenUrls | SitecoreInfoUrlOptions.SiteResolving | SitecoreInfoUrlOptions.LanguageEmbeddingAlways)]
        public string Url { get; set; }

        [SitecoreInfo(SitecoreInfoType.Url, UrlOptions = SitecoreInfoUrlOptions.EncodeNames | SitecoreInfoUrlOptions.AlwaysIncludeServerUrl | SitecoreInfoUrlOptions.SiteResolving | SitecoreInfoUrlOptions.LanguageEmbeddingAlways)]
        public string FullUrl { get; set; }
    }
}