﻿using Glass.Mapper.Sc.Configuration;
using Glass.Mapper.Sc.Configuration.Attributes;
using Glass.Mapper.Sc.Fields;
using Sitecore.Data.Items;
using System;
using System.Collections.Generic;
using Car.Common.Glassmapper;
using Car.User_Defined.Car.Base_Templates;
using Car.User_Defined.Car.Folder_Templates;
using Car.User_Defined.Car.Item_Templates;
using Car.User_Defined.Car.Page_Templates;
using Image = Glass.Mapper.Sc.Fields.Image;
using Link = Glass.Mapper.Sc.Fields.Link;

namespace Car.User_Defined.Car.Base_Templates
{
    ///
    /// <summary>
    /// Path: /sitecore/templates/User Defined/Car/Base Templates/Promotion Messages
    /// </summary>
    public partial interface IPromotionMessages : IGlassBase
    {
        [SitecoreField("Good Weather Promotion")]
        string GoodWeatherPromotion { get; set; }

        [SitecoreField("Bad Weather Promotion")]
        string BadWeatherPromotion { get; set; }

    }
    [SitecoreType(TemplateId = TEMPLATE_ID, AutoMap = true, Cachable = true, EnforceTemplate = SitecoreEnforceTemplate.Template)]
    public partial class PromotionMessages : GlassBase, IPromotionMessages
    {
        public const string TEMPLATE_ID = "{57D0F9C2-6C9C-4F2B-B022-30120DA54EBC}";
        [SitecoreField("Good Weather Promotion")]
        public virtual string GoodWeatherPromotion { get; set; }

        [SitecoreField("Bad Weather Promotion")]
        public virtual string BadWeatherPromotion { get; set; }
    }
}
namespace Car.User_Defined.Car.Component_Templates
{

}
namespace Car.User_Defined.Car.Folder_Templates
{

}
namespace Car.User_Defined.Car.Page_Templates
{

}
namespace Car.User_Defined.Car.Item_Templates
{

}